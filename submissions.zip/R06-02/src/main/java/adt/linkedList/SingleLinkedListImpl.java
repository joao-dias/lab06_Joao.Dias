package adt.linkedList;

public class SingleLinkedListImpl<T> implements LinkedList<T> {

	protected SingleLinkedListNode<T> head;

	public SingleLinkedListImpl() {
		this.head = new SingleLinkedListNode<T>();
	}

	@Override
	public boolean isEmpty() {
		return head.isNIL();
	}

	@Override
	public int size() {
		int tamanho = 0;
		SingleLinkedListNode<T> auxHead = head;
		
		while (!auxHead.isNIL()){
			tamanho += 1;
			auxHead = auxHead.next;
		}
		return tamanho;
	}

	@Override
	public T search(T element) {
		SingleLinkedListNode<T> auxHead = head;
		
		while (!auxHead.isNIL()){
			if (auxHead.getData().equals(element)){
				return auxHead.getData();
			}
		}
		return null;
	}

	@Override
	public void insert(T element) {
		SingleLinkedListNode<T> auxHead = head;
		
		if (head.isNIL()){
			SingleLinkedListNode<T> NewHead = new SingleLinkedListNode<T>(element, head);
			head = NewHead;
		} else {
			while (!auxHead.next.isNIL()){
				auxHead = auxHead.next;
			}
			
			SingleLinkedListNode<T> newNode = new SingleLinkedListNode<T>(element, auxHead.next);
			auxHead.next = newNode;
		}
	}

	@Override
	public void remove(T element) {
		if (head.getData().equals(element)){
			head = head.next;
		} else {
			SingleLinkedListNode<T> auxHead = head;
			SingleLinkedListNode<T> previous = auxHead;
			
			while ((!auxHead.isNIL()) && (!auxHead.getData().equals(element))){
				previous = auxHead;
				auxHead = auxHead.next;
			}
			
			if (!auxHead.isNIL()){
				previous.next = auxHead.next;
			}
		}
	}

	@Override
	public T[] toArray() {
		Integer array[] = new Integer[size()];
		SingleLinkedListNode<T> aux = head;
		int indice = 0;
		
		while (!aux.isNIL()){
			array[indice++] = (Integer) aux.getData();
			aux = aux.next;
		}
		return (T[]) array;
	}

	public SingleLinkedListNode<T> getHead() {
		return head;
	}

	public void setHead(SingleLinkedListNode<T> head) {
		this.head = head;
	}

}
